<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "database1";
$conn = mysqli_connect($servername,$username,$password,$database);
if(!$conn)
{
    die("Sorry We Failed To Connect".mysqli_connect_error());
}
else
{
    echo "Connection Was Successfull";
}
$destination = "India";
$sql = "UPDATE `php` SET `dest` = '$destination' WHERE `php`.`sno` = 3;";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "<br>Record Was Updated Successfully";
}
else
{
    echo "<br>Record Was Not Updated";
}
?>