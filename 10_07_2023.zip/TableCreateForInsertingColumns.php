<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "database1";
$conn = mysqli_connect($servername,$username,$password,$database);
if(!$conn)
{
    die("Sorry We Failed To Connect<br>".mysqli_connect_error());
}
else
{
    echo "Connection Was Successfull<br>";
}

$sql = "CREATE TABLE `php` (`sno` INT(6) NOT NULL AUTO_INCREMENT , `name` VARCHAR(12) NOT NULL, `dest` VARCHAR(20) NOT NULL , PRIMARY KEY (`sno`))";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "Table Was Created Successfully";
}
else
{
    echo "Table Was Not Created";
}
?>