<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "database1";
$conn = mysqli_connect($servername,$username,$password,$database);
if(!$conn)
{
    die("Sorry We Failed To Connect".mysqli_connect_error());
}
else
{
    echo "Connection Was Successfull";
}
$name = "Darshal";
$destination = "India";
$sql = "INSERT INTO `php` (`name`, `dest`) VALUES ('$name', '$destination')";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "<br>Record Was Inserted Successfully";
}
else
{
    echo "<br>Record Was Not Inserted";
}
?>